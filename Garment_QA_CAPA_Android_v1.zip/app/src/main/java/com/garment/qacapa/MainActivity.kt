package com.garment.qacapa

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var factoryEdit: EditText
    private lateinit var dateEdit: EditText
    private lateinit var apiKeyEdit: EditText
    private lateinit var defectEdit: EditText
    private lateinit var rootCauseEdit: EditText
    private lateinit var actionEdit: EditText
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var shareButton: Button
    private var imageUri: Uri? = null
    private var generatedFile: File? = null

    private val pickImage = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            imageUri = uri
            preview.setImageURI(uri)
            status.text = "Photo selected."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        factoryEdit = findViewById(R.id.factoryEdit)
        dateEdit = findViewById(R.id.dateEdit)
        apiKeyEdit = findViewById(R.id.apiKeyEdit)
        defectEdit = findViewById(R.id.defectEdit)
        rootCauseEdit = findViewById(R.id.rootCauseEdit)
        actionEdit = findViewById(R.id.actionEdit)
        preview = findViewById(R.id.previewImage)
        status = findViewById(R.id.statusText)
        shareButton = findViewById(R.id.shareButton)

        dateEdit.setText(SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date()))

        findViewById<Button>(R.id.selectImageButton).setOnClickListener {
            pickImage.launch("image/*")
        }
        findViewById<Button>(R.id.analyzeButton).setOnClickListener {
            analyze()
        }
        findViewById<Button>(R.id.generateButton).setOnClickListener {
            generatePpt()
        }
        shareButton.setOnClickListener {
            generatedFile?.let { shareFile(it) }
        }
    }

    private fun analyze() {
        val uri = imageUri ?: run { status.text = "Please select a defect photo."; return }
        val key = apiKeyEdit.text.toString().trim()
        if (key.isBlank()) { status.text = "Please enter your OpenAI API key."; return }

        status.text = "Analyzing defect..."
        findViewById<Button>(R.id.analyzeButton).isEnabled = false

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                val mime = contentResolver.getType(uri) ?: "image/jpeg"
                val b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)

                val prompt = """
You are a professional garment QA inspector. Analyze the supplied defect photo.
Return ONLY JSON with keys:
defect, root_cause, corrective_action, severity.
Use concise professional buying-office QA wording.
Do not invent measurements or standards not visible in the photo.
Root cause should be a likely process cause and can say factory investigation is required when uncertain.
Corrective action must be practical and specific.
""".trimIndent()

                val input = JSONObject().apply {
                    put("model", "gpt-5.6-luna")
                    put("input", org.json.JSONArray().put(
                        JSONObject().apply {
                            put("role", "user")
                            put("content", org.json.JSONArray()
                                .put(JSONObject().apply {
                                    put("type", "input_text")
                                    put("text", prompt)
                                })
                                .put(JSONObject().apply {
                                    put("type", "input_image")
                                    put("image_url", "data:$mime;base64,$b64")
                                })
                            )
                        }
                    ))
                }

                val client = OkHttpClient()
                val body = input.toString().toRequestBody("application/json".toMediaType())
                val req = Request.Builder()
                    .url("https://api.openai.com/v1/responses")
                    .addHeader("Authorization", "Bearer $key")
                    .post(body)
                    .build()

                client.newCall(req).execute().use { resp ->
                    val txt = resp.body?.string() ?: ""
                    if (!resp.isSuccessful) throw Exception("OpenAI error ${resp.code}: $txt")
                    val json = JSONObject(txt)
                    val outputText = json.getString("output_text")
                    val clean = outputText.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
                    val result = JSONObject(clean)
                    withContext(Dispatchers.Main) {
                        defectEdit.setText(result.optString("defect"))
                        rootCauseEdit.setText(result.optString("root_cause"))
                        actionEdit.setText(result.optString("corrective_action"))
                        status.text = "Analysis complete. Review/edit the wording, then generate PPT."
                        findViewById<Button>(R.id.analyzeButton).isEnabled = true
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    status.text = "Analysis failed: ${e.message}"
                    findViewById<Button>(R.id.analyzeButton).isEnabled = true
                }
            }
        }
    }

    private fun generatePpt() {
        val uri = imageUri ?: run { status.text = "Please select a defect photo."; return }
        if (defectEdit.text.isBlank()) { status.text = "Please analyze or enter the defect first."; return }

        status.text = "Creating PowerPoint..."
        findViewById<Button>(R.id.generateButton).isEnabled = false

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val inputBytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                val out = File(cacheDir, "QA_CAPA_${System.currentTimeMillis()}.pptx")

                val tmpDir = File(cacheDir, "pptx_${System.currentTimeMillis()}").apply { mkdirs() }
                unzipAsset("qa_capa_template.pptx", tmpDir)

                // Replace the defect photo.
                File(tmpDir, "ppt/media/image1.jpg").outputStream().use { fos ->
                    val bmp = BitmapFactory.decodeByteArray(inputBytes, 0, inputBytes.size)
                    bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, fos)
                    bmp.recycle()
                }

                val slide = File(tmpDir, "ppt/slides/slide1.xml")
                var xml = slide.readText()

                xml = xml.replace("FACTORY: HOA VU (GUOTAI)", escape(factoryEdit.text.toString()))
                xml = xml.replace(Regex("DATE: [^<]+"), "DATE: ${escape(dateEdit.text.toString())}")

                // Better image fit: fill the left image panel with preserved aspect ratio using a larger crop box.
                xml = xml.replace(
                    Regex("""<a:off x="2011870" y="3832008"/><a:ext cx="36195" cy="16942"/>"""),
                    """<a:off x="160000" y="1180000"/><a:ext cx="3740000" cy="5480000"/>"""
                )

                xml = xml.replace(
                    "Roping has been observed at the bottom hem.",
                    escape(defectEdit.text.toString())
                )

                val cap = "ROOT CAUSE: ${rootCauseEdit.text.toString()}\n\nCORRECTIVE ACTION: ${actionEdit.text.toString()}"
                xml = xml.replace(
                    Regex("""ROOT CAUSE:.*?free from roping\.</a:t>""", RegexOption.DOT_MATCHES_ALL),
                    escape(cap) + "</a:t>"
                )

                // Enable wrapping + shrink-to-fit on all text bodies in the middle column.
                xml = xml.replace("""<a:bodyPr wrap="none"><a:spAutoFit/></a:bodyPr>""",
                    """<a:bodyPr wrap="square"><a:normAutofit/></a:bodyPr>""")

                slide.writeText(xml)

                zipDirectory(tmpDir, out)
                tmpDir.deleteRecursively()

                generatedFile = out
                withContext(Dispatchers.Main) {
                    status.text = "PowerPoint created successfully."
                    shareButton.visibility = View.VISIBLE
                    findViewById<Button>(R.id.generateButton).isEnabled = true
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    status.text = "PPT creation failed: ${e.message}"
                    findViewById<Button>(R.id.generateButton).isEnabled = true
                }
            }
        }
    }

    private fun escape(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun unzipAsset(name: String, dest: File) {
        assets.open(name).use { input ->
            ZipInputStreamCompat(input).use { zis ->
                while (true) {
                    val entry = zis.nextEntry ?: break
                    val out = File(dest, entry.name)
                    if (entry.isDirectory) out.mkdirs()
                    else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { zis.copyTo(it) }
                    }
                }
            }
        }
    }

    private fun zipDirectory(dir: File, out: File) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zos ->
            dir.walkTopDown().filter { it.isFile }.forEach { f ->
                val name = f.relativeTo(dir).path.replace(File.separatorChar, '/')
                zos.putNextEntry(ZipEntry(name))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    private fun shareFile(file: File) {
        // For this first build, use a content URI via a FileProvider once the provider is added.
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share PowerPoint"))
    }
}

// Small wrapper so Android code does not depend on java.util.zip ZipInputStream name collision.
private class ZipInputStreamCompat(input: InputStream) : java.util.zip.ZipInputStream(input)
